### Mini-AlphaGo 复现 ###

For training, see bashes/ for examples.
For testing, run python3 MCTS/mcts_vs_random.py