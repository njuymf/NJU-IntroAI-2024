cd ../MCTS
python3 alg_vs_random.py --output_channels 4,4,8,8,16,16  
python3 alg_vs_random.py --output_channels 2,4,8,16,32  
python3 alg_vs_random.py --output_channels 2,2,4,4,8,16  